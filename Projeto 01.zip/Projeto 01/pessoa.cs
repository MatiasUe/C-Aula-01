
Pessoa xunda = new Pessoa();
xunda.nome = "Xunda";
xunda.idade = 12;

xunda.apresentar_se();



