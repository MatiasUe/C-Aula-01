﻿class Pessoa
{

    //propriedades
    public string nome;
    
    public int idade;


    public void apresentar_se(){

        Console.WriteLine("Meu nome é"  +nome+ ", e tenho " +idade+ "anos de idade");

    }

}    